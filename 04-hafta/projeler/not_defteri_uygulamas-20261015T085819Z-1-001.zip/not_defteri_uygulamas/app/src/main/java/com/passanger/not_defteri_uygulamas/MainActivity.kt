package com.passanger.not_defteri_uygulamas

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * ADIM 4: Ana ekran kodlarımızı (MainActivity) yazıyoruz.
 * Burada kullanıcı etkileşimlerini alıp listemizi güncelleyeceğiz.
 */
class MainActivity : AppCompatActivity() {

    // Notlarımızı hafızada tutacağımız dinamik bir liste oluşturuyoruz
    private val noteList = mutableListOf<String>()
    
    /**
     * Android'de çok sayıda veriyi (örneğin 100 tane notu) ekranda listelemek için modern ve verimli bir bileşen olan
     * RecyclerView kullanılır. Ancak RecyclerView tek başına hangi veriyi göstereceğini veya bu verinin nasıl bir
     * tasarımla ekranda duracağını bilmez.
     * İşte Adapter (Adaptör), verileriniz (not listesi) ile görsel arayüz (tasarım) arasında bir köprü görevi görür.
     *
     * lateinit (late initialize): Kotlin dilinde güvenliği artırmak adına tanımlanan her değişkenin daha ilk satırda
     * bir değere (örneğin 0, "" veya null) sahip olması zorunludur.
     * Ancak Android dünyasında arayüz bileşenleri ve adaptörler sınıf açılır açılmaz (daha onCreate metodu çalışmadan)
     * oluşturulamaz. Çünkü ekranın ve uygulamanın sistem parçalarının (Context) hazır olması beklenmelidir.
     * Burada imdadımıza lateinit (Late Initialization - Gecikmeli Başlatma) yetişir:
     * 
     * • Söz Vermiş Olursun: Kotlin'e dersin ki: "Ben bu noteAdapter değişkenini şimdi sınıfın en üstünde tanımlıyorum
     * ama değerini hemen vermiyorum. onCreate fonksiyonu içinde buna kesinlikle bir değer atayacağım,
     * bana güven ve hata verme."
     **/
    private lateinit var noteAdapter: NoteAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ADIM 5: Edge-to-Edge (Uçtan Uca) özelliğini aktif ediyoruz.
        // Bu özellik uygulamanın ekranın en tepesine (durum çubuğunun altına) kadar yayılmasını sağlar.
        enableEdgeToEdge()

        // Ana ekran tasarımımızı (activity_main.xml) yüklüyoruz
        setContentView(R.layout.activity_main)

        // Sistem çubuklarının (saat, pil simgesi, alt navigasyon) kapladığı alanları hesaplayıp
        // uygulamamıza iç boşluk (padding) olarak ekliyoruz. Böylece tasarımımız bu simgelerin altında kalmaz.
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Arayüzdeki (XML) bileşenlerimizi ID'leri yardımıyla koda bağlıyoruz
        val editTextNote = findViewById<EditText>(R.id.editTextNote)
        val buttonAdd = findViewById<Button>(R.id.buttonAdd)
        val recyclerViewNotes = findViewById<RecyclerView>(R.id.recyclerViewNotes)

        // Adaptörümüzü oluşturup içine boş listemizi veriyoruz
        noteAdapter = NoteAdapter(noteList)
        
        // RecyclerView'ın yukarıdan aşağıya doğru düz bir liste halinde listelemesini istiyoruz
        recyclerViewNotes.layoutManager = LinearLayoutManager(this)
        
        // Tasarladığımız adaptörü RecyclerView bileşenine atıyoruz
        recyclerViewNotes.adapter = noteAdapter

        // "Ekle" butonuna basıldığında yapılacak işlemler
        buttonAdd.setOnClickListener {
            // Kullanıcının yazdığı metni alıyoruz ve başındaki/sonundaki boşlukları temizliyoruz
            val noteText = editTextNote.text.toString().trim()

            // Eğer kullanıcı boş bir şey yazmadıysa listeye ekliyoruz
            if (noteText.isNotEmpty()) {
                // Metni dinamik listemize ekliyoruz
                noteList.add(noteText)
                
                // Adaptöre listeye yeni bir eleman eklendiğini haber veriyoruz (Böylece ekranda hemen görünür)
                // noteList.size - 1 yapıyoruz çünkü listeler 0'dan başlar, yeni eleman sonuncu indekstedir.
                noteAdapter.notifyItemInserted(noteList.size - 1)
                
                // Giriş kutusunu yeni notlar yazılabilmesi için temizliyoruz
                editTextNote.text.clear()
            }
        }
    }
}
