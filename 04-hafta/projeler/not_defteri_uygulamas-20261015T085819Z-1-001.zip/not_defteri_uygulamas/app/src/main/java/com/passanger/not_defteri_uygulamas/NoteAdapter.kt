package com.passanger.not_defteri_uygulamas

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * ADIM 2: RecyclerView için bir Adapter oluşturuyoruz.
 * Adapter, verilerimiz (not listesi) ile arayüz (item_note.xml) arasındaki köprüdür.
 *
 * KOTLİN BİLGİSİ: Kotlin'de sınıflar direkt olarak parantez içinde parametre alabilir.
 * Buna "Primary Constructor" (Birincil Kurucu Fonksiyon) denir. Buradaki 'private val notes' tanımı
 * hem bu sınıfın kurucu fonksiyonunun parametresidir hem de sınıfın içinde her yerden erişilebilen
 * otomatik bir değişkene (property) dönüşür.
 */
class NoteAdapter(private val notes: List<String>) : RecyclerView.Adapter<NoteAdapter.NoteViewHolder>() {

    /**
       *
     * KOTLİN BİLGİSİ: 'view: View' parametresi bu sınıfın kurucu fonksiyonuna (Primary Constructor)
     * dışarıdan gönderilen tek bir satırın görsel tasarımını (item_note.xml) temsil eder.
     * Önünde val veya var olmadığı için bu 'view' sadece ilk oluşturulma anında (init bloğunda veya
     * üst sınıfa miras verirken) kullanılabilir. Üst sınıf olan RecyclerView.ViewHolder(view) yapısına
     * bu görsel şablonu miras/parametre olarak teslim ederiz.
     */

    //Her bir satırın içindeki bileşenleri tanımladığımız ve hafızada tuttuğumuz yardımcı sınıf.
    class NoteViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        // view.findViewById diyerek gelen şablonun içindeki TextView bileşenini bulup hafızaya alıyoruz
        val textViewNote: TextView = view.findViewById(R.id.textViewNoteText)
    }

    // onCreateViewHolder fonksiyonun görevi şudur: "Bana bir satır taslağı (item_note.xml) oluştur ve bunu bir
    // NoteViewHolder kutusunun içine koyup bana geri ver (return)."
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {//NoteViewHolder sınıfı değil ,
        // geri dönüş tipini temsil ediyor.
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_note, parent, false)
        return NoteViewHolder(view)
    }

    // Listedeki not sayısını döndürüyoruz
    override fun getItemCount(): Int = notes.size

    // Hangi satıra hangi verinin yazılacağını belirliyoruz
    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        holder.textViewNote.text = notes[position]
    }
}
